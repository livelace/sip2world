.. _celery:

======
Celery
======


.. include:: ./celery/celery-installation.rst


.. toctree::
    :maxdepth: 2

    ./celery/celery-configuration
