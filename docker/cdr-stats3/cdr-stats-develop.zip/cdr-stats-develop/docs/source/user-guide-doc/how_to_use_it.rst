.. _userguide-how-to-use-it:

How to use CDR-Stats
--------------------

CDR-Stats has two main areas, the admin screen and the customer portal. The admin and customer areas
are described in detail in the following pages.

CDR-Stats has been designed to be responsive, that is to say the the layout changes depending on the
size and resolution of the browser viewing the pages.
