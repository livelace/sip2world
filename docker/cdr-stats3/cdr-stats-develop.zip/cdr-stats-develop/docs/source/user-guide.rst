.. _root-user-guide:

==========
User Guide
==========

.. include:: ./user-guide-doc/overview.rst

.. include:: ./user-guide-doc/how_to_use_it.rst


.. toctree::
    :maxdepth: 2

    ./user-guide-doc/admin_panel
    ./user-guide-doc/customer_panel