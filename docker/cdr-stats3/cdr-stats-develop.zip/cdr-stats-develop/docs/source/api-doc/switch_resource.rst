.. automodule:: apirest.switch_serializers

.. _switch-model-resource:

:class:`SwitchSerializer`
-------------------------

.. autoclass:: SwitchSerializer
