.. automodule:: apirest.view_voip_rate

.. _voip-rate-api-resource:

:class:`VoIPRateList`
---------------------

.. autoclass:: VoIPRateList
