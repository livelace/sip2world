.. automodule:: api.voip_call

.. _voip-call-resource:

:class:`VoipCallResource`
-------------------------

.. autoclass:: VoipCallResource
