.. _tasks:

CDR-Stats Tasks
===============

.. automodule:: cdr.tasks

.. _sync_cdr_pending-task:

:class:`sync_cdr_pending`
-------------------------

.. autoclass:: sync_cdr_pending
    :members:

.. automodule:: cdr_alert.tasks

.. _chk_alarm-task:

:class:`chk_alarm`
------------------

.. autoclass:: chk_alarm
    :members:

.. _blacklist_whitelist_notification-task:

:class:`blacklist_whitelist_notification`
-----------------------------------------

.. autoclass:: blacklist_whitelist_notification
    :members:


.. _send_cdr_report-task:

:class:`send_cdr_report`
------------------------

.. autoclass:: send_cdr_report
    :members:


.. automodule:: voip_billing.tasks

.. _rebilling-task:

:class:`RebillingTask`
----------------------

.. autoclass:: RebillingTask
    :members:


.. _reaggregate-task:

:class:`ReaggregateTask`
------------------------

.. autoclass:: RebillingTask
    :members: