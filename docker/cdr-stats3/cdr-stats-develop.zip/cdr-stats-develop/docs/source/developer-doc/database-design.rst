.. _database-design:

Database Design
===============

The current database schema is shown below:

.. image:: ../_static/images/model_cdr-stats.png
    :width: 700


Follow this link for more details : https://github.com/cdr-stats/cdr-stats/raw/master/docs/source/_static/images/model_cdr-stats.png