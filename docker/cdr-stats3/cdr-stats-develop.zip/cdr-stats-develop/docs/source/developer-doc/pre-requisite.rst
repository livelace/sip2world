.. _prerequisites:

Prerequisites
=============

To fully understand this project, developers will need to have a advanced knowledge of:
    - Django : http://www.djangoproject.com/
    - Celery : http://www.celeryproject.org/
    - Python : http://www.python.org/
    - Freeswitch : http://www.freeswitch.org/
    - Asterisk : http://www.asterisk.org/
