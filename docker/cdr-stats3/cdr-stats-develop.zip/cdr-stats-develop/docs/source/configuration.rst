.. _configuration:

==========================
Configuration and Defaults
==========================

Contents:

.. toctree::
    :maxdepth: 2

    ./configuration/configuration-file
    ./configuration/configuration-country-reporting
    ./configuration/configuration-asterisk
    ./configuration/configuration-freeswitch
    ./configuration/configuration-reset-data
    ./celery/celery-configuration
    ./configuration/configuration-acl-control
