from cdr_stats import VERSION

VERSION = VERSION
